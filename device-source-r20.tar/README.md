# UniXNU on Meizu 21 — Darwin 22 transition

The owner chose UniXNU on 2026-11-02. This independent port keeps iOS 16.5,
the working native UFS path, Goodix touch and corrected 1080×2340 display.
The phone still runs **r16**. **r20 is an offline, unflashed candidate.**

## Current implementation

`ABL → existing clean shim → exact DEBUG firmware → MeizuBootBridge →`
`real UniXNU menu → UNIXNU_LOADER_PROTOCOL → retained loader → retained XNU → iOS`.

This is the first migration stage. It is not a completed replacement of the
kernel platform/drivers with UniXNU's native components. The menu automatically
starts the only iOS entry after two seconds; it has no touch input yet. Touch
inside iOS retains the already working kernel/userland path.

The board-owned bridge publishes an immutable in-memory filesystem to the
unmodified UniXNU application. It implements revision 2 of the loader protocol
and rejects unsupported ADT, ramdisk, kext and argument changes. The existing
loader still generates the Apple device tree and owns the memory handoff.

The 19 KiB bridge replaces the existing 68 KiB embedded-loader slot. UniXNU and
the exact original loader travel as extra XNUP records in the already reserved
payload range. The 54-file firmware volume keeps its layout and length; 53
files remain byte-identical. The kernel, small root ramdisk, command line,
shim, Android DTB and MemoryMap are preserved. No new diagnostic color holds.

## Protected state

- Never write `super`: it contains the existing iOS root and cryptex.
- Never flash `boot_a`, change partition geometry or switch slots.
- Stable r16 and r7 full boot images remain in the existing baseline directory.
- All firmware builds use DEBUG. This recipe invokes neither fastboot nor adb.
- `board.toml` is a format 2 transition profile. Its inventory DTS is not the
  Apple ADT. The actual Android DTB stays the pinned baseline DTB.

## VM workspace and build

The workspace is `/home/xiaochen/unixnu-port/`:

- `UniXNU/`: pinned upstream `04573c510c5fd4892ca6948739389141cc9e05f5`.
- `UniXNU-meizu21/`: this repository, bridge, packaging and evidence.
- `kernel-ios16/`: independent full copy of the current patched kernel source.
- `build/r20-transition/uefi-r20-unixnu-transition.img`: candidate boot image.

Run from this device repository:

```sh
bash scripts/package.sh --check
bash scripts/package.sh
```

`configure.py` resolves the device-owned iOS 16 profile and selected source
tree. Use this board's packaging script for stage 1. Do not run the generic
UniXNU `build kernel`, `build userdata`, `build payload` or `bootimg` commands
as replacements: their native kernel/root/boot-shim recipes are not this
transition's preserved-storage recipe.

The UEFI menu/bridge compile for real. ASan/UBSan cover the payload parser;
QEMU covers menu/config/filesystem/protocol handoff with a mock kernel receiver.
QEMU does not execute the phone's kernel or validate touch, UFS or the GPU.
`evidence/packaging-check.json` has the current image hashes and verification
limits. `evidence/kernel-snapshot.json` identifies the preserved source archive.

## Native migration work remaining

1. Device-test r20: menu, kernel handoff, desktop, repeated touches, Dock and reboot.
2. Port DarwinBoot to the real 608-byte command-line/736-byte boot_args ABI,
   32 MiB placement and this kernel's physical/virtual window policy. Its default
   Darwin 23 structure is 1152 bytes and is not safe for this kernel.
3. Replace the retained ADT/platform/HID/runtime services one interface at a
   time. Audit the root's libhakios/backboardd injection before replacing input.
4. Implement Meizu A750 power/SMMU/GMU/HFI/submission and the iOS 16 frontend.
   A740's sheng driver is not an A750 backend. Ace5's recorded GPU preparation
   does not establish working rendering or Metal on this phone.

The native loader component is pinned and selected for source review, but is
not installed alongside the transition loader: both publish the same protocol.
GPU acceleration remains unimplemented in r20.
