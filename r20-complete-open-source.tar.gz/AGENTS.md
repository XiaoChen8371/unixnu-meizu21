# Meizu 21 port instructions

Read README.md, board.toml, porting.toml and evidence/packaging-check.json first.
The owner explicitly chose UniXNU; continue the migration in this independent
workspace. Source and offline tests are authorized. Device tests need the owner
to return home; don't ask them to put the phone into fastboot while away.

Never write super, boot_a, partition tables or another device partition. Preserve
the full r16 and r7 images. Do not switch slots. Use DEBUG for every UEFI build.
Never introduce overlapping memory ranges. Back up source before modifying it.

Phone verification is distinct from QEMU/host verification. r20 uses the real
UniXNU menu/protocol and a retained Darwin22 loader/kernel. Do not call it a
completed native kernel/GPU migration. UEFI touch-menu input is not implemented;
iOS touch retains its existing kernel/userland path. Use scripts/package.sh,
not the generic native kernel/userdata/payload/boot-image recipes for stage 1.

Do not rebuild the divergent original Mu-Silicium/shim tree and substitute its
output for the pinned stable DEBUG binary. Preserve current sources and source
manifests. There is no permission to publish proprietary images or firmware.
